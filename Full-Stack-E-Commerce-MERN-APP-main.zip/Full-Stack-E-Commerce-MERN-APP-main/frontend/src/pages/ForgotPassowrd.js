import React from 'react'

const ForgotPassowrd = () => {
  return (
    <div>ForgotPassowrd</div>
  )
}

export default ForgotPassowrd